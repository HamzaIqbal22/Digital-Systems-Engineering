The following files were generated for 'ila2' in directory
/home/student2/h6iqbal/coe758/Tutorial1/ipcore_dir/

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * ila2.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * ila2.cdc
   * ila2.ngc
   * ila2.vhd
   * ila2.vho

Creates an HDL instantiation template:
   Creates an HDL instantiation template for the IP.

   * ila2.vho

IP Symbol Generator:
   Generate an IP symbol based on the current project options'.

   * ila2.asy

SYM file generator:
   Generate a SYM file for compatibility with legacy flows

   * ila2.sym

Generate ISE metadata:
   Create a metadata file for use when including this core in ISE designs

   * ila2_xmdf.tcl

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * _xmsgs/pn_parser.xmsgs
   * ila2.gise
   * ila2.xise

Deliver Readme:
   Readme file for the IP.

   * ila2_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * ila2_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

